The Zodiac St is 100% for any use.

I release the font for free for any use.

Help my work, all donations are greatly appreciated.

Even with a like on my facebook page can help me.

https://www.facebook.com/southype <- follow me ;)

Paypal: Southype@gmail.com

A Aries	
B Taurus
C Gemini	
D Cancer
E Leo	
F Virgo	
G Libra	
H Scorpio
I Ophiuchus
J Sagittarius
K Capricorn	
L Aquarius
M Pisces
O Aries	outline
P Taurus outline
Q Gemini outline
R Cancer outline
S Leo outline
T Virgo	outline
G Libra	outline
U Scorpio outline
V Ophiuchus outline
W Sagittarius outline
X Capricorn outline
Y Aquarius outline
Z Pisces outline